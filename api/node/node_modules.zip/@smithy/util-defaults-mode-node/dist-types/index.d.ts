/**
 * @internal
 */
export * from "./resolveDefaultsModeConfig";
