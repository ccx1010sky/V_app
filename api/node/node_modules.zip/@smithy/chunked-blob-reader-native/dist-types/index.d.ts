/**
 * @internal
 */
export declare function blobReader(blob: Blob, onChunk: (chunk: Uint8Array) => void, chunkSize?: number): Promise<void>;
