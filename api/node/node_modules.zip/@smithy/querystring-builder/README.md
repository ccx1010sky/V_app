# @smithy/querystring-builder

[![NPM version](https://img.shields.io/npm/v/@smithy/querystring-builder/latest.svg)](https://www.npmjs.com/package/@smithy/querystring-builder)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/querystring-builder.svg)](https://www.npmjs.com/package/@smithy/querystring-builder)

> An internal package

## Usage

You probably shouldn't, at least directly.
