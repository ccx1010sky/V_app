import { QueryParameterBag } from "@smithy/types";
/**
 * @internal
 */
export declare function buildQueryString(query: QueryParameterBag): string;
