/**
 * @internal
 */
export declare enum EndpointMode {
    IPv4 = "IPv4",
    IPv6 = "IPv6"
}
