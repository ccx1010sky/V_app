/// <reference types="node" />
import { RequestOptions } from "http";
/**
 * @internal
 */
export declare function httpRequest(options: RequestOptions): Promise<Buffer>;
