export const DEFAULT_TIMEOUT = 1000;
export const DEFAULT_MAX_RETRIES = 0;
export const providerConfigFromInit = ({ maxRetries = DEFAULT_MAX_RETRIES, timeout = DEFAULT_TIMEOUT, }) => ({ maxRetries, timeout });
