/**
 * @internal
 */
export declare const escapeUri: (uri: string) => string;
