/**
 * @internal
 */
export declare const escapeUriPath: (uri: string) => string;
