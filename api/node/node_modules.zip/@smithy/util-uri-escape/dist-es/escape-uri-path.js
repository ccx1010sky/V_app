import { escapeUri } from "./escape-uri";
export const escapeUriPath = (uri) => uri.split("/").map(escapeUri).join("/");
