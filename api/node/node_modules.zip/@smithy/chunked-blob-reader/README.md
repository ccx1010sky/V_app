# @smithy/chunked-blob-reader

[![NPM version](https://img.shields.io/npm/v/@smithy/chunked-blob-reader/latest.svg)](https://www.npmjs.com/package/@smithy/chunked-blob-reader)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/chunked-blob-reader.svg)](https://www.npmjs.com/package/@smithy/chunked-blob-reader)

> An internal package

## Usage

You probably shouldn't, at least directly.
