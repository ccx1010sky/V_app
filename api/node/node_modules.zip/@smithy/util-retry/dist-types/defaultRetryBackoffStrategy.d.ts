import { StandardRetryBackoffStrategy } from "@smithy/types";
/**
 * @internal
 */
export declare const getDefaultRetryBackoffStrategy: () => StandardRetryBackoffStrategy;
