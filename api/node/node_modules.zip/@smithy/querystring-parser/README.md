# @smithy/querystring-parser

[![NPM version](https://img.shields.io/npm/v/@smithy/querystring-parser/latest.svg)](https://www.npmjs.com/package/@smithy/querystring-parser)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/querystring-parser.svg)](https://www.npmjs.com/package/@smithy/querystring-parser)

> An internal package

## Usage

You probably shouldn't, at least directly.
