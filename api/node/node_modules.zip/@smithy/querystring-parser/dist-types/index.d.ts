import { QueryParameterBag } from "@smithy/types";
/**
 * @internal
 */
export declare function parseQueryString(querystring: string): QueryParameterBag;
