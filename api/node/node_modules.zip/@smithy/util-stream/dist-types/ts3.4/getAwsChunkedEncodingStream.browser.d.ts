import { GetAwsChunkedEncodingStream } from "@smithy/types";
/**
 * @internal
 */
export declare const getAwsChunkedEncodingStream: GetAwsChunkedEncodingStream<ReadableStream>;
