/// <reference types="node" />
import { GetAwsChunkedEncodingStream } from "@smithy/types";
import { Readable } from "stream";
/**
 * @internal
 */
export declare const getAwsChunkedEncodingStream: GetAwsChunkedEncodingStream<Readable>;
