import { SdkError } from "@smithy/types";
/**
 * @deprecated this is only used in the deprecated StandardRetryStrategy. Do not use in new code.
 */
export declare const defaultRetryDecider: (error: SdkError) => boolean;
