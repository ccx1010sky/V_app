import { SdkError } from "@smithy/types";
export declare const asSdkError: (error: unknown) => SdkError;
