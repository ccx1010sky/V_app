export const isStreamingPayload = (request) => request?.body instanceof ReadableStream;
