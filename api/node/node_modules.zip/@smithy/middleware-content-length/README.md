# @smithy/middleware-content-length

[![NPM version](https://img.shields.io/npm/v/@smithy/middleware-content-length/latest.svg)](https://www.npmjs.com/package/@smithy/middleware-content-length)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/middleware-content-length.svg)](https://www.npmjs.com/package/@smithy/middleware-content-length)
