/**
 * @internal
 */
export declare const invalidFunction: (message: string) => () => never;
