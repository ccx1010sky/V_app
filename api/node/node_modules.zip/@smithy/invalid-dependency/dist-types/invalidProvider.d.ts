import { Provider } from "@smithy/types";
/**
 * @internal
 */
export declare const invalidProvider: (message: string) => Provider<any>;
