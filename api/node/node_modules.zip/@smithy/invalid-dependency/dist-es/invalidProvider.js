export const invalidProvider = (message) => () => Promise.reject(message);
