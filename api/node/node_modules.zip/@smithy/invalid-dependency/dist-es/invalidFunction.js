export const invalidFunction = (message) => () => {
    throw new Error(message);
};
