/**
 * @internal
 */
export declare const BLOCK_SIZE = 64;
/**
 * @internal
 */
export declare const DIGEST_LENGTH = 16;
/**
 * @internal
 */
export declare const INIT: number[];
